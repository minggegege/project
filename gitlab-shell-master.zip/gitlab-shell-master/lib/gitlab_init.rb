ROOT_PATH = File.expand_path(File.join(File.dirname(__FILE__), ".."))

require_relative 'gitlab_config'
